package info.enjoycode.countdown;

import info.enjoycode.countdown.CountDownUtils.CountDownListener;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MultiCountDownActivity extends Activity {
	private Button btn1;
	private Button btn2;
	private Button btn3;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_other);
		btn1 = $(R.id.btn1);
		btn2 = $(R.id.btn2);
		btn3 = $(R.id.btn3);
		//传入需要倒计时的按钮
		countDown(MultiCountDownActivity.this, btn1,btn2,btn3);	
	}

	private void countDown(Activity activity,Button ... btns) {
		for(int i = 0;btns!=null&&i<btns.length;i++){
			final Button btn = btns[i];
			final int btnFlag = btn.getId();
			CountDownUtils.prepareCountDown(activity, btnFlag, new CountDownListener() {

				@Override
				public void onCounting(int currentCount) {
					btn.setText(currentCount + "");
				}

				@Override
				public void onCountStart() {
					btn.setEnabled(false);
				}

				@Override
				public void onCountEnd() {
					btn.setText("倒计时结束");
					btn.setEnabled(true);
				}

				@Override
				public void onError(String msg) {
//					btn.setText(msg);
				}
			});

			btn.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					//启动倒计时
					CountDownUtils.countDown(15,btnFlag);
				}
			});
		}
		

	}

	public <T> T $(int viewId) {
		return (T) findViewById(viewId);
	}

}
