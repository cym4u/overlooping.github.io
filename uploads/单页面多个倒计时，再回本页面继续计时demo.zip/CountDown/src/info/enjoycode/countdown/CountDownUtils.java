package info.enjoycode.countdown;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;

public class CountDownUtils {
	static Map<String, Long> countDownMap = new HashMap<>();
	static Map<String, Timer> countDownTimerMap = new HashMap<>();
	static Map<String, CountDownListener> countDownListnerMap = new HashMap<>();

	static Activity activity;

	/**
	 * 需要倒计时的时候调用
	 * 
	 * @MethodName: countDown
	 * @param count
	 *            倒计时秒数
	 * @param btnFlag
	 *            被点击的按钮标识
	 * @author Chen Yuanming
	 * @date 2015年2月11日 下午2:10:37
	 */
	public static void countDown(int count, int btnFlag) {
		final String key = activity.getClass().getName() + btnFlag;
		CountDownListener listener = countDownListnerMap.get(key);
		if (listener == null) {
			throw new RuntimeException("必须在onCreate或者onResume方法中先调用prepareCountDown方法,并且CountDownListener不能为空");
		}
		if (activity == null) {
			listener.onError("必须在onCreate或者onResume方法中先调用prepareCountDown方法,并且传入当前Acitivity的引用");
		}
		if (countDownMap.get(key) == null) {
			// 首次进入或者上次倒计时已经结束
			countDownMap.put(key, System.currentTimeMillis() + count * 1000);
		} else {
			// 上次倒计时还没结束，继续
			return;
		}
		countDown(activity, btnFlag, listener, key);
	}

	/**
	 * Activity启动的时候就调用
	 * 
	 * @MethodName: prepareCountDown
	 * @param activity
	 *            当前acitivity
	 * @param btnFlag
	 *            被点击的按钮标识
	 * @param listener
	 *            回调
	 * @author Chen Yuanming
	 * @date 2015年2月11日 下午2:10:14
	 */
	public static void prepareCountDown(final Activity activity, int btnFlag, final CountDownListener listener) {
		CountDownUtils.activity = activity;
		final String key = activity.getClass().getName() + btnFlag;
		countDownListnerMap.put(key, listener);
		if (countDownMap.get(key) != null) {
			// 上次倒计时还没结束，继续
			long expireTime = countDownMap.get(key);
			int remainTime = (int) ((expireTime - System.currentTimeMillis()) / 1000);
			if (remainTime <= 0) {
				countDownMap.remove(key);
				countDownTimerMap.remove(key);
				countDownListnerMap.remove(key);
				return;
			}
			countDownTimerMap.remove(key).cancel();
			countDown(activity, btnFlag, listener, key);
		} else {
			// 首次进入或者上次倒计时已经结束，准备阶段暂不做其他操作
		}

	}

	private static void countDown(final Activity activity, int btnFlag, final CountDownListener listener, final String key) {
		final Timer timer = new Timer();
		countDownTimerMap.put(key, timer);
		activity.runOnUiThread(new Runnable() {
			public void run() {
				listener.onCountStart();
			}
		});
		TimerTask task = new TimerTask() {

			@Override
			public void run() {
				long expireTime = countDownMap.get(key);
				final int remainTime = (int) ((expireTime - System.currentTimeMillis()) / 1000);
				if (remainTime > 0) {
					activity.runOnUiThread(new Runnable() {
						public void run() {
							listener.onCounting(remainTime);
						}
					});
				} else {
					timer.cancel();
					countDownMap.remove(key);
					countDownTimerMap.remove(key);
					countDownListnerMap.remove(key);

					activity.runOnUiThread(new Runnable() {
						public void run() {
							listener.onCountEnd();
						}
					});
				}

			}
		};
		timer.schedule(task, 0, 1000);
	}

	public interface CountDownListener {
		/**
		 * 倒计时刚启动的回调
		 * 
		 * @MethodName: onCountStart
		 * @author Chen Yuanming
		 * @date 2015年2月11日 下午2:12:53
		 */
		public void onCountStart();

		/**
		 * 倒计时过程中的回调
		 * 
		 * @MethodName: onCounting
		 * @param currentCount
		 * @author Chen Yuanming
		 * @date 2015年2月11日 下午2:13:16
		 */
		public void onCounting(int currentCount);

		/**
		 * 倒计时结束
		 * 
		 * @MethodName: onCountEnd
		 * @author Chen Yuanming
		 * @date 2015年2月11日 下午2:13:40
		 */
		public void onCountEnd();

		/**
		 * 发生错误的时候回调,一般是参数传递错误
		 * 
		 * @MethodName: onError
		 * @param msg
		 * @author Chen Yuanming
		 * @date 2015年2月11日 下午2:13:56
		 */
		public void onError(String msg);
	}
}
