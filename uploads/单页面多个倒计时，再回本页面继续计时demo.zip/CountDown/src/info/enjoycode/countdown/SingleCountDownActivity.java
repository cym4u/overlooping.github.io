package info.enjoycode.countdown;

import info.enjoycode.countdown.CountDownUtils.CountDownListener;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class SingleCountDownActivity extends Activity {
	private Button btn1;
	private Button btn2;
	private Button btn3;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_other);
		btn1 = $(R.id.btn1);
		btn2 = $(R.id.btn2);
		btn3 = $(R.id.btn3);
		btn2.setVisibility(View.GONE);
		btn3.setVisibility(View.GONE);
		
		
		final int btnFlag = btn1.getId();
		//activity启动前先调用此方法
		CountDownUtils.prepareCountDown(SingleCountDownActivity.this, btnFlag, new CountDownListener() {

			@Override
			public void onCounting(int currentCount) {
				btn1.setText(currentCount + "");
			}

			@Override
			public void onCountStart() {
				btn1.setEnabled(false);
			}

			@Override
			public void onCountEnd() {
				btn1.setText("倒计时结束");
				btn1.setEnabled(true);
			}

			@Override
			public void onError(String msg) {
//				btn.setText(msg);
			}
		});

		btn1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				//启动倒计时
				CountDownUtils.countDown(15,btnFlag);
			}
		});
	}


	public <T> T $(int viewId) {
		return (T) findViewById(viewId);
	}

}
