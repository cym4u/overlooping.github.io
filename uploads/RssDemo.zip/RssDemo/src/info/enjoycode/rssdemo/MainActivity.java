package info.enjoycode.rssdemo;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.thebuzzmedia.sjxp.XMLParser;
import com.thebuzzmedia.sjxp.rule.DefaultRule;
import com.thebuzzmedia.sjxp.rule.IRule;
import com.thebuzzmedia.sjxp.rule.IRule.Type;

public class MainActivity extends Activity {
	private static int count = 0;

	private MockDAO dao = new MockDAO();
	String xpaths[] = { "/rss/channel/item/title", "/rss/channel/item/link",
			"/rss/channel/item/author", "/rss/channel/item/category",
			"/rss/channel/item/pubDate", "/rss/channel/item/comments",
			"/rss/channel/item/description" };

	private XMLParser<MockDAO> parser;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		IRule<MockDAO> rules[] = new DefaultRule[xpaths.length];
		for (int i = 0; i < rules.length; i++) {
			final String xpath = xpaths[i];
			rules[i] = new DefaultRule<MockDAO>(Type.CHARACTER, xpaths[i]) {
				@Override
				public void handleParsedCharacters(XMLParser<MockDAO> parser,
						String text, MockDAO dao) {
					/*
					 * This doesn't do anything, just a smoke-and-mirrors
					 * example of how I might use my user-object that was passed
					 * through to me from the XMLParser.parse method.
					 */
					dao.save(xpath.substring(xpath.lastIndexOf("/") + 1), text);
					count++;
				}
			};
		}
		;
		parser = new XMLParser<MockDAO>(rules);

		Button runButton = (Button) findViewById(R.id.runButton);
		runButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				count = 0;
				execute();
			}

		});
	}

	private void execute() {
		new AsyncTask<String, Integer, Void>() {
			long startTime;

			protected void onPreExecute() {
				startTime = System.currentTimeMillis();
			};

			@Override
			protected Void doInBackground(String... params) {
				try {

					HttpClient client = new DefaultHttpClient();
					String url = null;
					if (params.length == 1) {
						url = params[0];
					} else {
						url = "http://news.qq.com/newsgn/rss_newsgn.xml";
					}
					HttpGet get = new HttpGet(url);
					HttpResponse response = client.execute(get);
					if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
						InputStream is = response.getEntity().getContent();

						/*
						 * Start the parse operation and pass in our user
						 * object. SJXP doesn't do anything with the user object
						 * except keep it handy and then pass it through to the
						 * matching IRule so you can get access to it easily
						 * inside of your IRule handler method.
						 */
						parser.parse(is, dao);
					}
				} catch (Exception e) {
				}
				return null;

			}

			@Override
			protected void onPostExecute(Void result) {
				/*
				 * Parse is done! Just show how long it took in the UI.
				 */
				TextView view = (TextView) findViewById(R.id.resultView);
				Toast.makeText(MainActivity.this,"Parsed " + count + " RSS2 elements in "+ (System.currentTimeMillis() - startTime)+ "ms", Toast.LENGTH_LONG).show();

				StringBuffer sb = new StringBuffer();
				for (NewsItem item : list) {
					sb.append(item.toString()).append("\n");
				}
				view.setText(sb.toString());
				super.onPostExecute(result);
			}
		}.execute("http://news.qq.com/newsgn/rss_newsgn.xml");
	}

	/**
	 * This class does nothing, it is just a mock DAO to illustrate the example
	 * of using the user object pass-through functionality in SJXP 2.0 above.
	 * 
	 * @author Riyad Kalla (software@thebuzzmedia.com)
	 */
	class MockDAO {
		public void save(String key, String value) {
			if (xpaths[0].contains(key)) {
				newsItem = new NewsItem();
				list.add(newsItem);
			}
			try {
				Class clazz = newsItem.getClass();
				Field field = clazz.getDeclaredField(key);
				if (field != null) {
					field.set(newsItem, value);
				}
			} catch (NoSuchFieldException | IllegalAccessException
					| IllegalArgumentException e) {
				e.printStackTrace();
			}
			System.out.println(key + "-->" + value);
		}
	}

	List<NewsItem> list = new ArrayList<>();
	NewsItem newsItem;
}
