package info.enjoycode.rssdemo;

public class NewsItem {
	String title;
	String link;
	String author;
	String category;
	String pubDate;
	String comments;
	String description;
	@Override
	public String toString() {
		return "NewsItem [title=" + title + ", link=" + link + ", author="
				+ author + ", category=" + category + ", pubDate=" + pubDate
				+ ", comments=" + comments + ", description=" + description
				+ "]";
	}
	
}
