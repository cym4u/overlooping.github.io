package info.enjoycode.recyclerviewdemo;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends Activity {
	RecyclerView mRecyclerView;
	LinearLayoutManager mLayoutManager;
	MyAdapter mAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);

		// 如果你知道数据大小不变的话可以设置此项
		mRecyclerView.setHasFixedSize(true);

		// 设置线性布局管理器
		mLayoutManager = new LinearLayoutManager(this);
		mRecyclerView.setLayoutManager(mLayoutManager);

		// 设置个适配器
		List<String> dataList = new ArrayList<>();
		for (int i = 0; i < 20; i++) {
			dataList.add("item " + i);
		}
		mAdapter = new MyAdapter(dataList);
		mRecyclerView.setAdapter(mAdapter);
	}

}

class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
	private List<String> dataList;

	// 跟以前一样,写一个ViewHolder
	public static class ViewHolder extends RecyclerView.ViewHolder {
		public TextView mTextView;
		public ImageView mImageView;

		public ViewHolder(View v) {
			super(v);
			mTextView = (TextView) v.findViewById(R.id.tv);
			mImageView = (ImageView) v.findViewById(R.id.iv);
		}
	}

	// 构造
	public MyAdapter(List<String> dataList) {
		this.dataList = dataList;
	}

	// 创建ViewHolder
	@Override
	public MyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
		// 加载layout
		View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
		// new一个ViewHolder
		ViewHolder vh = new ViewHolder(v);
		return vh;
	}

	// 设置view的内容(由layout manager调用)
	@Override
	public void onBindViewHolder(ViewHolder holder, int position) {
		// - 从数据集获取指定位置的数据
		// - 替换view中对应的数据
		holder.mTextView.setText(dataList.get(position));

	}

	// 返回数据集大小 (由layout manager调用)
	@Override
	public int getItemCount() {
		return dataList.size();
	}
}