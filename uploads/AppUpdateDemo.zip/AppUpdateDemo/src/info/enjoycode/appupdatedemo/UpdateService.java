package info.enjoycode.appupdatedemo;

import java.io.File;

import android.annotation.TargetApi;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.view.WindowManager;
import android.widget.Toast;

/**
 * 更新
 *  http://www.enjoycode.info
 * @author ChenYuanming
 */
public class UpdateService extends Service {
	/**
	 * 下载地址
	 */
    private String down_url;
    /**
     * 是否强制更新，对应进度框能否取消
     */
    private boolean enforce;
    /**
     * 系统DownloadManager下载过程中分配的id
     */
    long downloadId;
    // 声明进度条对话框
    ProgressDialog progressDialog;
    /**
     * 下载用工具类：http://www.trinea.cn/android/android-downloadmanager/
     */
    DownloadManagerPro downloadManagerPro;
    /**
     * SD卡存储目录
     */
    public static final String DOWNLOAD_FOLDER_NAME = "Download";
    /**
     * SD卡存储文件名
     */
    public static final String DOWNLOAD_FILE_NAME = "QQ.apk";
    
    /**
     * 应用保存完整路径
     */
    String apkFilePath;
    /**
     * handler用更新状态
     */
    public static final int UPDATE_STATUS = 0;

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case UPDATE_STATUS:
                    int downloadInfos[] = downloadManagerPro.getDownloadBytes(downloadId);
                    if (downloadInfos[0] < downloadInfos[1]) {
                        if (enforce) {
                            progressDialog.setMessage(downloadInfos[0] + "/" + downloadInfos[1]);
                            progressDialog.setProgress((int) (downloadInfos[0] * 100 / downloadInfos[1]));
                        }
                    } else if (downloadInfos[0] > downloadInfos[1]) {
                        if (enforce) {
                            progressDialog.setMessage("初始化下载中");
                        }
                    } else {
                        if (enforce) {
                            progressDialog.setMessage(downloadInfos[1] + "/" + downloadInfos[1]);
                            progressDialog.setProgress(100);
                            progressDialog.cancel();
                        }
                        Toast.makeText(UpdateService.this, "下载完成", Toast.LENGTH_LONG).show();
                        install(getBaseContext(), apkFilePath);
                    }

                    if (downloadInfos[0] != downloadInfos[1]) {
                    	//只要没下载完，每秒更新进度
                        sendEmptyMessageDelayed(UPDATE_STATUS, 1000);
                    }
                    break;
            }
        }
    };


    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }


    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
	@Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            enforce = intent.getBooleanExtra("enforce", false);
            down_url = intent.getStringExtra("appurl");
            if (isSdCardExist()) {
                if (enforce) {
                    initProgressDialog();
                } else {
                    Toast.makeText(UpdateService.this, "应用后台更新中", Toast.LENGTH_LONG).show();
                }
                File folder = Environment.getExternalStoragePublicDirectory(DOWNLOAD_FOLDER_NAME);
                if (!folder.exists()) {
                    folder.mkdirs();

                }
                apkFilePath = folder.getAbsolutePath() + File.separator + DOWNLOAD_FILE_NAME;
                /**
                 * 如果对下载参数不了解，或者是理解上有问题 详情请见原文链接：http://www.trinea.cn/android/android-downloadmanager/
                 */
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(down_url));
                request.setDestinationInExternalPublicDir(DOWNLOAD_FOLDER_NAME, DOWNLOAD_FILE_NAME);//存储位置、目录、文件名
                request.setTitle(getString(R.string.download_notification_title));//通知栏标题
                request.setDescription(getString(R.string.download_notification_description));//通知栏描述
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);//notify的显示形式，可以全部隐藏，可以下载时显示，可以下载完显示，可以下载时和下载完都显示
                request.setVisibleInDownloadsUi(true);//是否显示当前下载 在系统的下载界面上
                // request.allowScanningByMediaScanner();//允许媒体抓取
                // request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);//下载网络形式限定
                //request.setShowRunningNotification(false);//废弃的方法
                request.setAllowedOverRoaming(true);//移动网络情况下是否允许漫游
                downloadManagerPro = new DownloadManagerPro((DownloadManager) getSystemService(DOWNLOAD_SERVICE));
                downloadId = downloadManagerPro.getDownloadId(request);
                handler.sendEmptyMessage(UPDATE_STATUS);
            } else {
                Toast.makeText(getApplicationContext(), getApplication().getString(R.string.no_sd), Toast.LENGTH_LONG).show();
            }
        }
        return super.onStartCommand(intent, flags, startId);
    }


    private void initProgressDialog() {
        // 创建ProgressDialog对象
        progressDialog = new ProgressDialog(UpdateService.this);
        // 设置进度条风格，风格为圆形，旋转的
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        // 设置ProgressDialog 标题
        progressDialog.setTitle(getApplicationContext().getString(R.string.common_dialog_title));
        // 设置ProgressDialog提示信息
        progressDialog.setMessage(getApplicationContext().getString(R.string.software_updating) + "···");
        // 设置ProgressDialog标题图标
        // progressDialog.setIcon(R.drawable.ic_launcher);
        // 设置ProgressDialog 的进度条是否不明确 false 就是不设置为不明确
        progressDialog.setIndeterminate(false);
        // 设置ProgressDialog 进度条进度
        progressDialog.setProgress(100);
        // 设置ProgressDialog 是否可以按退回键取消
        progressDialog.setCancelable(!enforce);
        progressDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
        // 让ProgressDialog显示
        progressDialog.show();
    }

    /**
     * install app
     *
     * @param context  上下文环境
     * @param filePath 文件路径
     * @return whether apk exist
     */
    public static boolean install(Context context, String filePath) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        File file = new File(filePath);
        if (file.length() > 0 && file.exists() && file.isFile()) {
            i.setDataAndType(Uri.parse("file://" + filePath), "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        }
        return false;
    }

    /**
     * 判断sd卡是否存在
     *
     * @return boolean
     */
    private boolean isSdCardExist() {
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            return true;
        } else
            return false;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        downloadManagerPro.remove(downloadId);
    }
}
