package info.enjoycode.appupdatedemo;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

/**
 * 应用强制更新和非强制更新demo
 * http://www.enjoycode.info
 *
 * @author ChenYuanming
 */
public class MainActivity extends Activity implements OnClickListener {

    String downurl = "http://gdown.baidu.com/data/wisegame/2c6a60c5cb96c593/QQ_182.apk";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        $(R.id.btnNormalUpdate).setOnClickListener(this);
        $(R.id.btnForceUpdate).setOnClickListener(this);
    }


    public <T extends View> T $(int viewId) {
        return (T) findViewById(viewId);
    }

    public <T extends View> T $(View view, int viewId) {
        return (T) view.findViewById(viewId);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
		switch (v.getId()) {
            case R.id.btnNormalUpdate:
                showUpdateDialog(false, getString(R.string.common_dialog_cancel), new AppVersionInfo(downurl, getString(R.string.normal_update)));
                break;
            case R.id.btnForceUpdate:
                showUpdateDialog(true, getString(R.string.exit), new AppVersionInfo(downurl, getString(R.string.force_update)));

                break;
        }
    }

    private void showUpdateDialog(final boolean enforce, String strNegativeButton, final AppVersionInfo ver) {
        Builder alert = new Builder(MainActivity.this);
        alert.setCancelable(!enforce);
        alert.setTitle(getString(R.string.update_software)).setMessage(ver.getUpdateinfo().replace(";", "\n"))
                .setPositiveButton(getString(R.string.update), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Intent updateIntent = new Intent(MainActivity.this, UpdateService.class);
                        updateIntent.putExtra("appurl", ver.getDownurl());
                        updateIntent.putExtra("enforce", enforce);
                        startService(updateIntent);
                    }
                }).setNegativeButton(strNegativeButton, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                if (enforce) {
                    finish();
                }
            }
        });
        if (!isFinishing())
            alert.create().show();
    }

    class AppVersionInfo {
        String downurl, updateinfo;

        AppVersionInfo(String downurl, String updateinfo) {
            this.downurl = downurl;
            this.updateinfo = updateinfo;
        }

        public String getDownurl() {
            return downurl;
        }

        public String getUpdateinfo() {
            return updateinfo;
        }
    }
}
